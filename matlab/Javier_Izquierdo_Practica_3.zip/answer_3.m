% En x p1 y en y p2
p1 = q1 + r1 + l2*cos(q2);
p2 = l2*sin(q2);